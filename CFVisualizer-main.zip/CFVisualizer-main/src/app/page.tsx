"use client";
import { CodeforcesVisualizerComponent } from "../components/codeforces-visualizer";
// import Head from "next/head";
export default function Home() {
  return (
    <div className="">
      {/* <Head>
        <link rel="icon" href="/favicon.ico" />
      </Head> */}

      <CodeforcesVisualizerComponent />
    </div>
  );
}
